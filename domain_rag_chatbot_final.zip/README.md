# Domain-Specific RAG Chatbot

## Project Description
This project is a Domain-Specific Retrieval-Augmented Generation (RAG) chatbot that answers questions using information from uploaded PDF documents.

## Technologies Used
- Python
- Streamlit
- Ollama with Qwen2.5 1.5B
- Sentence Transformers
- FAISS
- PyPDF
- LangChain Text Splitters

## Features
- Reads information from PDF documents.
- Splits documents into smaller text chunks.
- Converts text into embeddings.
- Retrieves relevant information using FAISS.
- Generates answers using a local language model.
- Displays source document information.
- Avoids answering questions that are not supported by the documents.

## Project Files
- `app.py` - Streamlit user interface.
- `document_loader.py` - Extracts text from PDF documents.
- `vector_store.py` - Creates and searches the vector database.
- `prompt.py` - Defines the chatbot instructions.
- `rag_pipeline.py` - Connects retrieval and answer generation.
- `requirements.txt` - Lists Python dependencies.
- `documents/` - Contains sample PDF documents.

## Installation
Install the Python dependencies:

```bash
pip install -r requirements.txt
```

Install Ollama separately and download the model:

```bash
ollama pull qwen2.5:1.5b
```

Make sure Ollama is running before starting the chatbot.

## Run the Application
Start the Streamlit application:

```bash
streamlit run app.py
```

Open the local URL displayed in the terminal.

## Workflow
PDF document → Text extraction → Text chunking → Embeddings → FAISS retrieval → Ollama LLM → Answer with sources

## Testing
The chatbot was tested with questions related to the uploaded Operating Systems notes and unrelated questions. It is designed to provide answers based on the uploaded document and refuse unsupported questions.

## Future Enhancements
- Support multiple PDF documents.
- Add more domain-specific document collections.
- Improve retrieval accuracy.
- Add a chat history feature.
