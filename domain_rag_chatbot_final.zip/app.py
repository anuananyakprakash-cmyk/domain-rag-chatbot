
import os
import sys
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from document_loader import load_and_split_pdfs
from vector_store import VectorStore
from rag_pipeline import answer_question

st.set_page_config(
    page_title="Domain-Specific RAG Chatbot",
    page_icon="📚",
    layout="wide"
)

st.title("📚 Domain-Specific RAG Chatbot")
st.write(
    "Upload PDF documents and ask questions based on their content."
)

if "vector_store" not in st.session_state:
    st.session_state.vector_store = None

if "messages" not in st.session_state:
    st.session_state.messages = []

if "processed_files" not in st.session_state:
    st.session_state.processed_files = []

with st.sidebar:
    st.header("Upload Documents")

    uploaded_files = st.file_uploader(
        "Choose PDF files",
        type=["pdf"],
        accept_multiple_files=True
    )

    if uploaded_files:
        st.write("Selected documents:")
        for file in uploaded_files:
            st.write(f"📄 {file.name}")

    if st.button("Process Documents", use_container_width=True):

        if not uploaded_files:
            st.warning("Please upload at least one PDF.")

        else:
            total_size = sum(
                len(file.getvalue()) for file in uploaded_files
            )

            if total_size > 25 * 1024 * 1024:
                st.error("Total upload size must be below 25 MB.")

            else:
                try:
                    with st.spinner(
                        "Extracting text and creating embeddings..."
                    ):
                        documents = load_and_split_pdfs(uploaded_files)

                        if not documents:
                            raise ValueError(
                                "No readable text found in the PDFs."
                            )

                        store = VectorStore()
                        store.build(documents)

                        st.session_state.vector_store = store
                        st.session_state.messages = []
                        st.session_state.processed_files = [
                            file.name for file in uploaded_files
                        ]

                    st.success(
                        f"Successfully processed {len(uploaded_files)} PDF(s)."
                    )

                except Exception as error:
                    st.error(f"Processing failed: {error}")

    st.divider()

    if st.button("Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    st.caption(
        "Please verify important answers against the original documents."
    )

if st.session_state.vector_store is None:
    st.info(
        "Upload your PDF files and click Process Documents to begin."
    )

else:
    st.success("Your documents are ready!")

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

            if message.get("sources"):
                with st.expander("View Sources"):
                    for source in message["sources"]:
                        st.write(
                            f"📄 {source['source']} — "
                            f"Page {source['page']}"
                        )

    question = st.chat_input("Ask a question about your documents...")

    if question:
        st.session_state.messages.append({
            "role": "user",
            "content": question
        })

        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Finding the answer..."):
                try:
                    answer, sources = answer_question(
                        question,
                        st.session_state.vector_store
                    )

                    st.markdown(answer)

                    if sources:
                        with st.expander("View Sources"):
                            for source in sources:
                                st.write(
                                    f"📄 {source['source']} — "
                                    f"Page {source['page']}"
                                )

                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": answer,
                        "sources": sources
                    })

                except Exception as error:
                    st.error(f"Could not generate answer: {error}")
