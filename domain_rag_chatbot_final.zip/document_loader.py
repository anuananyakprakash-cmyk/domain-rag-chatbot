
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter


def load_and_split_pdfs(uploaded_files):
    documents = []

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=900,
        chunk_overlap=150
    )

    for uploaded_file in uploaded_files:
        reader = PdfReader(uploaded_file)

        for page_number, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            text = text.strip()

            if not text:
                continue

            chunks = splitter.split_text(text)

            for chunk in chunks:
                if chunk.strip():
                    documents.append({
                        "text": chunk,
                        "source": uploaded_file.name,
                        "page": page_number
                    })

    return documents
