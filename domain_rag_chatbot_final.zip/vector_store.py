
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


class VectorStore:

    def __init__(self):
        self.model = SentenceTransformer(
            "sentence-transformers/all-MiniLM-L6-v2"
        )
        self.index = None
        self.documents = []

    def build(self, documents):

        if not documents:
            raise ValueError("No document chunks available.")

        texts = [doc["text"] for doc in documents]

        embeddings = self.model.encode(
            texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=True
        )

        embeddings = np.asarray(
            embeddings,
            dtype="float32"
        )

        self.index = faiss.IndexFlatIP(
            embeddings.shape[1]
        )

        self.index.add(embeddings)

        self.documents = documents

        print("Embeddings created successfully!")
        print("Number of vectors:", self.index.ntotal)

    def search(self, question, top_k=4):

        if self.index is None:
            raise ValueError(
                "Please build the vector database first."
            )

        query_embedding = self.model.encode(
            [question],
            convert_to_numpy=True,
            normalize_embeddings=True
        ).astype("float32")

        k = min(top_k, len(self.documents))

        scores, indices = self.index.search(
            query_embedding,
            k
        )

        results = []

        for score, idx in zip(scores[0], indices[0]):

            if idx < 0:
                continue

            document = self.documents[idx].copy()
            document["score"] = float(score)

            results.append(document)

        return results
